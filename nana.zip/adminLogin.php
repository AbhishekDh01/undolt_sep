<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
</head>
<body>

	<form action="adminLoginBack.php" method="POST" style="text-align: center;">
		<h1>Admin Login</h1>

		<input type="email" name="aEmail" placeholder="email-id" required="required">

		<input type="password" name="aPass" placeholder="password" required="required">

		<input type="submit" name="aLogin" value="Login">
		
	</form>
</body>
</html>
